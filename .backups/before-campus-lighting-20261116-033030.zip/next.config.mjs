export default {
  devIndicators: false,
};
