'use client';

import { Application } from '@pixi/react';
import { TextureSource } from 'pixi.js';
import { useEffect, useRef, useState } from 'react';
import AmbientEffects from './ambient-effects';
import HuntInterface from './hunt-interface';
import { RoundMarkers } from './round-display';

TextureSource.defaultOptions.scaleMode = 'nearest';

export default function PixelScene() {
  const sceneRef = useRef(null);
  const [moving, setMoving] = useState(false);
  const pointer = useRef({ x: -1000, y: -1000 });

  useEffect(() => {
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setMoving(!preference.matches && !document.hidden);
    update();
    preference.addEventListener('change', update);
    document.addEventListener('visibilitychange', update);
    return () => {
      preference.removeEventListener('change', update);
      document.removeEventListener('visibilitychange', update);
    };
  }, []);

  return (
    <div
      ref={sceneRef}
      className="pixel-scene"
      id="home"
      onPointerMove={(event) => {
        const bounds = event.currentTarget.getBoundingClientRect();
        pointer.current = { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
      }}
      onPointerLeave={() => { pointer.current = { x: -1000, y: -1000 }; }}
    >
      <div className="campus-map">
        <img
        className="campus-art"
        src="/art/reva-campus-oscode.png"
        alt="Pixel-art REVA University campus with turquoise treasure portals, three backpack adventurers, cherry blossoms, waterfalls, and a glowing path through the gardens. Blue mist opens across the upper-left sky."
        fetchPriority="high"
        />
        <RoundMarkers />
      </div>
      <div className="atmosphere" aria-hidden="true">
        <div className={`mist ${moving ? 'mist-moving' : ''}`} />
        <Application resizeTo={sceneRef} antialias={false} backgroundAlpha={0} autoStart={false} roundPixels>
          <AmbientEffects pointer={pointer} moving={moving} />
        </Application>
      </div>
      <HuntInterface />
    </div>
  );
}
